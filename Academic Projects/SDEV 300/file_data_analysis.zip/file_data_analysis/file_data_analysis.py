"""loading area for import"""
import sys
import pandas as pd
import matplotlib.pyplot as plt


def data_file_csv(file_csv):
    """open and load any csv based on the file name"""
    data_file = pd.read_csv(file_csv)
    return data_file


def main():
    """main function of the python """

    # welcome message and menu.
    print()
    print("************ Welcome to the Python Data Analysis App ****************")
    print()

    while True:
        print("Select the file you want to analyze")

        # Create a dictionary to store menu options
        menu = {
            '1': "Population Data",
            '2': "Housing Data",
            '3': "Exit the program",
        }

        # Display the menu options
        options = sorted(menu.keys())
        for entry in options:
            print(entry, menu[entry])
        print()

        user_input = input('Enter selection here: ').lower()

        print()

        # user input from the menu
        if user_input == '3':
            print("************ Thanks for using the Data Analysis App *************")
            sys.exit()
        elif user_input == '1':
            option_pop_change = data_file_csv('PopChange.csv')
            column_list = option_pop_change.columns.tolist()
            get_user_choice(column_list, option_pop_change)
        elif user_input == '2':
            option_housing = data_file_csv('Housing.csv')
            column_list = option_housing.columns.tolist()
            get_user_choice(column_list, option_housing)
        else:
            print("Invalid input. Please choose from an available file.")
            print()
            print('select only from the options below.')
            print("************************************")
            print()


def display_menu(column_list):

    """display the list of column in a menu"""
    column_selection_input = column_list
    actual_dict = create_dict(column_selection_input)

    print("Select the Column you want to analyze: ")
    for key, value in actual_dict.items():
        print(f"{key}: {value}")


def create_dict(column_names_input):

    """creating a dictionary from the columns in the csv file"""
    column_names = column_names_input
    file_as_dict = {}

    # Use the alphabet as keys and add fruits to the corresponding lists
    # Get the corresponding alphabet (a, b, c, ...)
    key_code_point = ord("a")
    item_input = 0

    # specific columns are not used and excluded from the dictionary
    while item_input < len(column_names):

        key = chr(key_code_point)

        if key == 'q':
            key_code_point += 2
            item_input += 1
        elif column_names[item_input] not in ('Id', 'Geography', 'Target Geo Id',
                                              'Target Geo Id2', 'NUNITS', 'WEIGHT'):
            file_as_dict[key] = column_names[item_input]
            key_code_point += 1
            item_input += 1
        else:
            item_input += 1

    return file_as_dict


def data_analysis(column_selection, data_df):

    """this function is used to analysis data in the CSV loaded earlier and print a graph"""
    print("The statistics for this column are: ")
    column_selection_input = column_selection
    data_frame_input = data_df

    value_counts = data_frame_input[column_selection_input].count()
    mean_value = data_frame_input[column_selection_input].mean()

    mean_value_formatted = mean_value.round(1)

    standard_devi = data_frame_input[column_selection_input].std()

    standard_devi_formatted = standard_devi.round(1)

    min_value = data_frame_input[column_selection_input].min()
    max_value = data_frame_input[column_selection_input].max()

    print()
    print(f"Count = {value_counts}")
    print(f"mean = {mean_value_formatted}")
    print(f"Standard Deviation = {standard_devi_formatted}")
    print(f"Min = {min_value}")
    print(f"Max = {max_value}")
    print()
    print("The Histogram of this column is now displayed")
    print()

    # Plot a histogram
    data_frame_input.hist(column=column_selection_input)
    plt.xlabel(column_selection)
    plt.ylabel('Range ')
    plt.title(f'Histogram of {column_selection_input}')
    plt.show()


def get_user_choice(column_list, data_df):

    """ this function is used to get use input and validate the input """
    menu_dict = create_dict(column_list)
    data_frame_input = data_df

    while True:
        display_menu(column_list)
        print()
        user_input = input("Select the Column you want to analyze: (or 'q' to quit): ").lower()
        print()
        if user_input == 'q':
            main()
            break
        elif user_input in menu_dict:
            print(f"Selected item: {menu_dict[user_input]}")
            column_selection = menu_dict[user_input]
            data_analysis(column_selection, data_frame_input)
        else:
            print("Invalid input. Please choose from the columns available.")


if __name__ == '__main__':
    main()
