""" staging area for all imports"""
import os  # Provides functions for interacting with the operating system
import re  # Provides regular expression matching operations
from datetime import datetime  # Basic date and time types

import pandas as pd  # Data manipulation and analysis library
from flask import Flask, render_template, url_for, request, flash, redirect, session
# Web framework
from passlib.hash import sha256_crypt  # Password hashing library


def load_file():
    """Loads a CSV file into a pandas DataFrame"""
    data = pd.read_csv('table.txt', encoding='latin-1')
    return data


def validate_passcode(entered_password):
    """Validates the entered password based on certain criteria"""
    # Create a regex pattern with positive lookaheads
    pattern = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*\W).{8,}$')
    password_input = str(entered_password)

    if (len(entered_password)) < 12:
        return False
    elif re.match(pattern, password_input):
        return True
    else:
        return False


def load_users():
    """Loads user data from a file"""
    users = {}
    with open("passfile", "r") as file:
        for line in file:
            username, hashed_password = line.strip().split(":")
            users[username] = hashed_password
    return users


def pwd_context(username, entered_password):
    """Checks if the entered password matches the stored password for the user"""
    users = load_users()

    try:
        is_member = users[username]
        return sha256_crypt.verify(entered_password, is_member)
    except KeyError:
        return False


# the main function of python
def main():
    """the main function of the deliverables"""

    # a flask app is created within python main function
    app = Flask(__name__)
    app.secret_key = os.urandom(24)  # Sets a secret key for the Flask application

    @app.route("/spells", methods=['GET'])
    def spells():
        """Publishes a table using pandas"""
        table = load_file()
        html_table = table.to_html()
        if request.method == 'GET':
            if 'logged_in' not in session:
                return redirect(url_for('login'))
            else:
                return render_template('spells.html', html_table=html_table)

    @app.route("/login", methods=['GET', 'POST'])
    def login():
        """Handles user login"""
        if request.method == 'POST':
            username = request.form.get("username")
            entered_password = request.form.get("password")

            users = load_users()

            if not username:
                flash('Username is required')
            elif not entered_password:
                flash('A password is requested')
            elif username in users:
                if pwd_context(username, entered_password):
                    session['logged_in'] = True
                    # session['username'] = request.form['username']
                    return redirect('/')
            else:
                flash('unknown user or incorrect password')

        return render_template('login.html',
                               title='access page')

    @app.route("/signup", methods=['GET', 'POST'])
    def signup():
        """Handles user registration"""
        users = load_users()

        if request.method == 'POST':
            username = request.form.get("username")
            password = request.form.get("password")

            # Hash the password
            hashed_password = sha256_crypt.hash(password)

            if not username:
                flash('Username is required')
            elif not password:
                flash('A password is requested')
            elif not validate_passcode(password):
                flash("password show be complex, 12 min digital"
                      "1 uppercase, 1 lowercase, 1 number and 1 special character")
            else:
                if username in users:
                    flash("That username is already taken, please choose another")
                    return render_template('signup.html', title='sign-up')
                else:
                    # Store user data in the text file
                    with open("passfile", "a") as file:
                        file.write(f"{username}:{hashed_password}\n")

                    flash("Thank you for registering")
                    return redirect(url_for('signup'))

        return render_template('signup.html', title='sign-up')

    @app.route('/', methods=['GET', 'POST'])
    def index():
        """Renders the home page"""
        if request.method == "GET":

            if 'logged_in' not in session:
                return redirect(url_for('login'))
            else:
                current_time = datetime.now()
                return render_template('index.html',
                                       title="Welcome Mel's Nebula Arcana",
                                       pagetime=current_time)

    @app.route('/nebula/', methods=['GET'])
    def nebula_cipher():
        """Renders a page with a list of ciphers"""
        cipher_list = [
            "Aetherium Codex",
            "Nebuloglyphs",
            "Quantum Enigma",
            "Stellar Cartography",
            "Cosmic Lexicon"
        ]

        if request.method == 'GET':
            if 'logged_in' not in session:
                return redirect(url_for('login'))
            else:
                return render_template('reading.html',
                                       title='Nebula Cipher',
                                       pagelist=cipher_list)

    @app.route('/stellar/', methods=['GET'])
    def stellar_tome():
        """Renders a page with a list of tomes"""
        tome = ['Astrogrimoire', 'Nebulomnicon', 'Stellarcana', 'Cosmochronicles',
                'Cosmochronicles',
                'Astronominomicon',
                'Galaxicon']

        if request.method == 'GET':
            if 'logged_in' not in session:
                return redirect(url_for('login'))
            else:
                return render_template('reading.html', title='Stellar Tome', pagelist=tome)

    @app.route('/astral/', methods=['GET'])
    def astral_codex():
        """Renders a page with a list of astral codex titles"""
        astral_codex_titles = [
            "Stellar Tome",
            "Nebula Ciper",
            "Cosmic Lexica",
            "Astronomicon Scrolls",
            "Celestial Codices",
            "Ethereal Archives"
        ]

        if request.method == 'GET':
            if 'logged_in' not in session:
                return redirect(url_for('login'))
            else:
                return render_template('reading.html', title='Astral Codex',
                                       pagelist=astral_codex_titles
                                       )

    @app.route('/about/', methods=['GET'])
    def about():
        """Renders the about page"""
        if request.method == 'GET':
            if 'logged_in' not in session:
                return redirect(url_for('login'))
            else:
                return render_template('about.html', title='Join Our Cosmic Quest',
                                       )

    # the flask app is called and run
    app.run()  # Starts the Flask application with debug mode enabled


# the main function is run
if __name__ == "__main__":
    main()  # Calls the main function
