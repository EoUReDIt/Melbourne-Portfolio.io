"""These are the imported packages for the program to work as expected"""
import re
import sys
import numpy as np


def input_with_exit(prompt):
    """This is function to validate if the program should be exited"""
    # removing case-sensitivity
    value = prompt.lower()

    if value == 'n':
        print()
        print("Exiting...")
        print("****** Thanks for playing python Numpy ******")
        sys.exit()
    return value


# EOF ======


def validate_mobile(number):
    """The function is used for validating the user's input of the phone number"""
    # Regular expression pattern for valid phone numbers
    pattern_international = re.compile(r"(?:\+\d{1,3})?\s?\(?\d{1,4}\)?[\s.-]?\d{3}[\s.-]?\d{4}")
    pattern_minimum_length = re.compile(r"^\d{10,}$")

    # Searching the phone number for defined pattern.
    try:
        if pattern_international.match(number):
            print("Valid mobile number")
            return True
        elif pattern_minimum_length.fullmatch(number):
            print("Valid mobile number (minimum length).")
            return True
        else:
            print("Invalid mobile number. Please enter a valid format.")
            return False
    except re.error:
        print("Error occurred while processing the phone number. Please check your input.")
        return False


def validate_zip(zip_code):
    """using regex to confirm the zip input matches expected format"""
    pattern = r"^\d{5}(?:[-\s]\d{4})?$"
    zip_match = re.match(pattern, zip_code)

    if zip_match:
        print('Valid Zip Code')
        return True
    else:
        print('invalid Zip Code')
        return False


def exit_notification():
    """re-usable function for exit notification"""
    print("Type, 'N for No' anytime to leave the program")


def welcome_message():
    """re-usable function of the welcome message"""
    print()
    print('*********** Welcome to the Python Matrix Application ************')
    print()
    print('Do you want to play the Matrix Games?')
    print()


def welcome_matrix():
    """re-usable function. You can disable as needed"""
    print()
    print('********the Matrix******')


def collect_matrix():
    """The function exist to collect the matrix input"""
    # take input for each element of the matrix
    user_input = input_with_exit(input('Enter the values in a single line (separated by space): '))

    try:
        # get input & convert it into a list
        entries = list(map(int, user_input.split()))

        # create a 3x3 matrix from the input
        matrix = np.array(entries).reshape(3, 3)
        return matrix
    except ValueError:
        print("Please re-enter using the correct format (separated by space)")
        print()
        print("try again")
        print()
        collect_matrix()


def matrix_transpose(result_input):
    """matrix transposing function"""
    result = np.transpose(result_input)
    print()
    print("The Transpose is: ")
    print()
    print(result)
    print()


def matrix_mean_values(result_input):
    """Computer the row and column values of the result """
    # Calculate row means
    row_means = np.mean(result_input, axis=1)

    # Calculate column means
    column_means = np.mean(result_input, axis=0)

    print("The row and column mean values of the results are")
    print("\nRow Means:")
    print(row_means)
    print("\nColumn Means:")
    print(column_means)


def matrix_addition(matrix1, matrix2):
    """matrix addition function"""
    result = matrix1 + matrix2
    print("You selected Addition. The results are: ")
    print()
    print(result)
    print()
    matrix_transpose(result)
    matrix_mean_values(result)


def matrix_subtract(matrix1, matrix2):
    """matrix subtraction function"""
    result = np.subtract(matrix1, matrix2)
    print("You selected Subtraction. The results are: ")
    print()
    print(result)
    print()
    matrix_transpose(result)
    matrix_mean_values(result)


def matrix_multi(matrix1, matrix2):
    """matrix multiple function"""
    result = np.matmul(matrix1, matrix2)
    print("You select Multiplication. The results are: ")
    print()
    print(result)
    print()
    matrix_transpose(result)
    matrix_mean_values(result)


def matrix_element(matrix1, matrix2):
    """matrix element-wise multiplication"""
    result = np.multiply(matrix1, matrix2)
    print("You selected Element by element multiplication")
    print()
    print(result)
    print()
    matrix_transpose(result)
    matrix_mean_values(result)


def main():
    """This is the main function of the program"""
    matrix_menu = {
        'a': ".Addition",
        'b': ".Subtraction",
        'c': ".Matrix Multiplication",
        'd': ".Element by element multiplication",
        'e': ".Exit"
    }

    def collect_phone_number():

        print("Enter your phone number (x-xxx-xxx-xxxx: ")
        while True:
            phone_num_input = input_with_exit(input())
            if validate_mobile(phone_num_input):
                print("<<<Thank you>>>")
                print()
                return None
            else:
                print("Your phone number is not in correct format. Please re-enter: ")
                print()
                return collect_phone_number()

    def collect_zip():

        print("Enter your zip code+4 (xxxxxx-xxxx): ")
        while True:
            zip_code_input = input_with_exit(input())
            if validate_zip(zip_code_input):
                print("<<<Thank you>>>")
                print()
                return None
            else:
                print("Your zip code is not in correct format. Please re-enter: ")
                return collect_zip()

    def matrix_operation():
        while True:
            welcome_matrix()
            print()
            # Display the menu options
            options = sorted(matrix_menu.keys())
            for entry in options:
                print(entry, matrix_menu[entry])
            print()

            # Prompt the user to select an option
            selection = input_with_exit(input("Please select: "))
            print()

            # Execute actions based on user's choice
            if selection == 'a':
                matrix_addition(matrix_value_1, matrix_value_2)
            elif selection == 'b':
                matrix_subtract(matrix_value_1, matrix_value_2)
            elif selection == 'c':
                matrix_multi(matrix_value_1, matrix_value_2)
            elif selection == 'd':
                matrix_element(matrix_value_1, matrix_value_2)
            elif selection == 'e':
                print()
                print('exit program')
                exit_notification()
                break
            else:
                print()
                print("Unknown option selected! Please try again.")

    # starting the user interface
    welcome_message()
    while True:
        user_input = input("Enter Y for Yes or N for No: ")
        user_input_str = user_input.lower()

        if user_input_str == 'y':
            collect_phone_number()
            collect_zip()

            print()
            exit_notification()
            print()
            print("Enter your first 3x3 matrix: ")
            print()
            matrix_value_1 = collect_matrix()
            print()
            print("Enter your second 3x3 matrix: ")
            matrix_value_2 = collect_matrix()

            matrix_operation()
            break
        elif user_input_str == 'n':
            print()
            print("Exiting...")
            print("****** Thanks for playing python Numpy ******")
            sys.exit()
        else:
            print()
            print("Unknown option selected! Please try again.")


# Calling the program
if __name__ == "__main__":
    main()
