import hashlib
import secrets


# input a message to encode
print('Enter a message to encode:')
message = input()

# encode it to bytes using UTF-8 encoding
message = message.encode()

"""Testing MD5"""
# hash with MD5 (very weak)
print()
print("MD5")
print(hashlib.md5(message, usedforsecurity=False).hexdigest())
print()

"""Testing salted MD5"""
# generating and converting secret random to bytes
m = secrets.randbelow(10)
nm = bytes([m]) + message

print("Salted MD5")
print(hashlib.md5(nm, usedforsecurity=False).hexdigest())
print()

"""Testing SHA256"""
# Lets try a stronger SHA-2 family
print("SHA256")
print(hashlib.sha256(message, usedforsecurity=False).hexdigest())
print()

"""Testing SHA512"""
print("SHA512")
print(hashlib.sha512(message, usedforsecurity=False).hexdigest())
