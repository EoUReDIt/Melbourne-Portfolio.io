""" staging area for all imports"""
from datetime import datetime
from flask import Flask
from flask import render_template


# the main function of python
def main():
    """the main function of the deliverables"""

    # a flask app is created within python main function
    app = Flask(__name__)

    # the home page is created
    @app.route('/')
    def index():
        """a function that generate the time and home page"""
        current_time = datetime.now()
        return render_template('index.html',
                               title="Welcome Mel's Nebula Arcana",
                               pagetime=current_time)

    # a subpage is generated called nebula cipher and a list is printed
    @app.route('/nebulacipher/')
    def nebula_cipher():
        cipher_list = [
            "Aetherium Codex",
            "Nebuloglyphs",
            "Quantum Enigma",
            "Stellar Cartography",
            "Cosmic Lexicon"
        ]

        return render_template('readlistd1.html',
                               title='Nebula Cipher',
                               pagelist=cipher_list)

    # one more subpage is created  using python function stellar_tome
    # and mapped using the app.route.
    @app.route('/stellartome/')
    def stellar_tome():
        """a function that uses the readlistd1 template and passes the information to flask"""
        tome = ['Astrogrimoire', 'Nebulomnicon', 'Stellarcana', 'Cosmochronicles',
                'Cosmochronicles',
                'Astronominomicon',
                'Galaxicon']
        return render_template('readlistd1.html', title='Stellar Tome', pagelist=tome)

    # third subpage created and mapped using app.route
    @app.route('/astralcodex/')
    def astral_codex():
        """ a function for the astral codex html page"""

        astral_codex_titles = [
            "Stellar Tome",
            "Nebula Ciper",
            "Cosmic Lexica",
            "Astronomicon Scrolls",
            "Celestial Codices",
            "Ethereal Archives"
        ]

        return render_template('readlistd1.html', title='Astral Codex',
                               pagelist=astral_codex_titles
                               )

    # last subpage created and mapped to about
    @app.route('/about/')
    def about():
        """the function that generates about page"""
        return render_template('about.html', title='Join Our Cosmic Quest',
                               )

    # the flask app is called and run
    app.run()


# the main function is run
if __name__ == "__main__":
    main()
